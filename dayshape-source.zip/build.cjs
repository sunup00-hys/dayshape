const fs=require('node:fs'),path=require('node:path');
const root=__dirname,read=p=>fs.readFileSync(path.join(root,p),'utf8');
let html=read('src/shell.html');
html=html.replace('<!--STYLE-->',()=>'<style>\n'+read('src/style.css')+'\n</style>');
for(const [tag,file]of [['CONFIG','config.js'],['CORE','src/core.js'],['LUNAR','src/lunar-data.js'],['HOLIDAYS','src/holidays.js'],['XLSX','src/xlsx.js'],['EXPORT','src/export.js'],['STORE','src/store.js'],['APP','src/app.js']]) html=html.replace('<!--'+tag+'-->',()=>'<script>\n'+read(file)+'\n</script>');
fs.mkdirSync(path.join(root,'dist'),{recursive:true});fs.writeFileSync(path.join(root,'dist/index.html'),html);fs.writeFileSync(path.join(root,'index.html'),html);console.log('Built dist/index.html ('+Buffer.byteLength(html)+' bytes)');
