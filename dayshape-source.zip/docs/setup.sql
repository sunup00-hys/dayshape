-- Prepared schema only. Not executed against any project.
-- Run once in a NEW, dedicated Dayshape Supabase project after deployment approval.
begin;
create table public.dayshape_items (
  id uuid primary key,
  owner_id uuid not null references auth.users(id) on delete cascade,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  version integer not null default 1 check (version > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint dayshape_kind check (payload->>'kind' in ('task','meeting','company')),
  constraint dayshape_title check (length(payload->>'title') between 1 and 120)
);
create index dayshape_items_owner_id_idx on public.dayshape_items(owner_id);
alter table public.dayshape_items enable row level security;
revoke all on table public.dayshape_items from anon;
grant select, insert, update, delete on table public.dayshape_items to authenticated;
create policy "Read own items" on public.dayshape_items for select to authenticated
  using ((select auth.uid()) = owner_id);
create policy "Create own items" on public.dayshape_items for insert to authenticated
  with check ((select auth.uid()) = owner_id);
create policy "Update own items" on public.dayshape_items for update to authenticated
  using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "Delete own items" on public.dayshape_items for delete to authenticated
  using ((select auth.uid()) = owner_id);
commit;
