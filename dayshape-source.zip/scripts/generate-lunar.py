"""Build offline Korean lunar holiday anchors. pip install korean-lunar-calendar==0.3.1"""
from korean_lunar_calendar import KoreanLunarCalendar
import json
from pathlib import Path
cal=KoreanLunarCalendar()
data={}
for year in range(2026,2051):
    dates=[]
    for month,day in [(1,1),(4,8),(8,15)]:
        assert cal.setLunarDate(year,month,day,False)
        dates.append(cal.SolarIsoFormat())
    data[year]=dates
Path(__file__).resolve().parents[1].joinpath('src/lunar-data.js').write_text('/* Korean lunar anchors: seollal, buddha, chuseok. Generated with korean-lunar-calendar 0.3.1 (MIT). */\nconst DayLunar = '+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\nif(typeof module!==\'undefined\')module.exports=DayLunar;\n')
