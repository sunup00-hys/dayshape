const DayExport=(()=>{
  const C=typeof DayCore!=='undefined'?DayCore:require('./core.js');
  const level={low:'낮음',normal:'보통',high:'높음'},portion={full:'종일',am:'오전',pm:'오후'};
  const date=d=>d?{date:d}:'';
  function pending(i){const end=[C.plusDays(C.today(),370),...C.fields(i).map(f=>f.date)].sort().at(-1);const list=C.occurrences([i],C.anchor(i),end);return list.find(e=>!e.done)||list.at(-1);}
  function sheets(items){const schedules=items.filter(i=>i.kind!=='task').sort((a,b)=>a.date.localeCompare(b.date)),tasks=items.filter(i=>i.kind==='task').sort((a,b)=>a.date.localeCompare(b.date));
    const note='내보낸 날짜: '+C.today()+' (한국 시간) · 등록 항목 전체 · 반복은 원본 1행 + 반복 규칙으로 표시';
    return [{name:'일정',note:note+' · 회사 일정 포함',headers:['구분','제목','시작일','종료일','시작 시간','종료 시간','종일 / 반일','장소','중요도','담당자','협업자 / 팀','반복','반복 종료일','리마크'],widths:[18,36,15,15,12,12,14,28,12,16,28,16,15,55],rows:schedules.map(i=>[i.kind==='company'?i.category:'미팅 / 약속',i.title,date(i.date),date(i.endDate||i.date),i.kind==='meeting'?i.start:'',i.kind==='meeting'?i.end:'',i.kind==='company'?portion[i.portion]:'',i.place||'',C.priorities[i.priority],i.owner||'',i.team||'',C.repeats[i.repeat],date(i.until),i.remark||''])},
    {name:'업무',note,headers:['업무명','중요도','남은 기간','챙길 단계','챙길 납기','난이도','효용성','업무 시작일','담당자','협업자 / 팀','기본 마감일','1차 프로토 납기','1차 검증','최종 납기','반복','반복 종료일','완료 기록 (회차·단계)','리마크'],widths:[36,12,14,18,15,12,12,15,16,28,15,17,15,15,16,15,45,60],rows:tasks.map(i=>{const e=pending(i);return[i.title,C.priorities[i.priority],e?C.deadline(e.date,e.done).label:'',e?C.stages[e.stage]:'',date(e?.date),level[i.difficulty]||'',level[i.utility]||'',date(i.begin),i.owner||'',i.team||'',date(i.date),date(i.proto),date(i.verify),date(i.final),C.repeats[i.repeat],date(i.until),Object.keys(i.completed||{}).filter(k=>i.completed[k]).map(k=>{const[n,s]=k.split(':');return`${Number(n)+1}회차 ${C.stages[s]||s}`;}).join('\n'),i.remark||''];})}];
  }
  return {sheets,pending,portion};
})();
if(typeof module!=='undefined')module.exports=DayExport;
