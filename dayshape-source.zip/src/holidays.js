/* 2026-27 verified against KASI/KASA; 2028-50 projected using law as of 2026-10-30. */
const DayHolidays = (() => {
  const C=typeof DayCore!=='undefined'?DayCore:require('./core.js');
  const lunar=typeof DayLunar!=='undefined'?DayLunar:require('./lunar-data.js');
  const cache=new Map();
  function year(y){
    if(cache.has(y))return cache.get(y);
    if(!lunar[y])return [];
    const entries=[],groups=[];
    const add=(date,title,sub=true)=>entries.push({date,title,sub});
    for(const [md,title,sub] of [['01-01','신정',false],['03-01','삼일절',true],['05-01','노동절',true],['05-05','어린이날',true],['06-06','현충일',false],['07-17','제헌절',true],['08-15','광복절',true],['10-03','개천절',true],['10-09','한글날',true],['12-25','성탄절',true]])add(y+'-'+md,title,sub);
    const [seollal,buddha,chuseok]=lunar[y]; add(buddha,'부처님오신날');
    for(const [mid,title]of [[seollal,'설날'],[chuseok,'추석']]){
      const dates=[-1,0,1].map(n=>C.plusDays(mid,n));
      groups.push({dates,title});dates.forEach((d,n)=>add(d,n===1?title:title+' 연휴',false));
    }
    if(y===2026)add('2026-06-03','전국동시지방선거',false);
    const dow=d=>C.date(d).getUTCDay(),count=d=>entries.filter(e=>e.date===d).length,triggers=new Map();
    function trigger(day,title){if(!triggers.has(day))triggers.set(day,[]);if(!triggers.get(day).includes(title))triggers.get(day).push(title);}
    for(const e of entries)if(e.sub&&([0,6].includes(dow(e.date))||count(e.date)>1))trigger(e.date,e.title);
    for(const g of groups)if(g.dates.some(d=>dow(d)===0||(![0,6].includes(dow(d))&&count(d)>1)))trigger(g.dates.at(-1),g.title);
    const occupied=new Set(entries.map(e=>e.date));
    for(const [base,titles]of [...triggers].sort(([a],[b])=>a.localeCompare(b))){let d=C.plusDays(base,1);while([0,6].includes(dow(d))||occupied.has(d))d=C.plusDays(d,1);occupied.add(d);add(d,'대체공휴일 ('+titles.join('·')+')',false);}
    const result=entries.map(({date,title})=>({date,title,source:'national',projected:y>2027})).sort((a,b)=>a.date.localeCompare(b.date));cache.set(y,result);return result;
  }
  function on(day){return year(Number(day.slice(0,4))).filter(h=>h.date===day);}
  function note(y){return y<2026||y>2050?'이 연도의 공휴일 자료는 지원하지 않습니다. (2026~2050년 지원)':y>2027?'예상 공휴일 · 현재 법령·음력 기준 계산입니다. 향후 선거일·임시공휴일·법령 변경은 추가 확인이 필요합니다.':'한국 공휴일 · 2026~2027년 공식 발표 및 개정 법령 반영 (확인: 2026.10.30)';}
  return {year,on,note};
})();
if(typeof module!=='undefined')module.exports=DayHolidays;
