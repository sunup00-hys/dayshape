const DayStore = (() => {
  const KEY='dayshape.preview.v1',SESSION='dayshape.connection.v1';
  class ConflictError extends Error {constructor(){super('다른 기기에서 변경된 항목입니다. 새로고침 후 다시 수정해 주세요.');}}
  function newCode(){return 'DS1-'+[...crypto.getRandomValues(new Uint8Array(32))].map(b=>b.toString(16).padStart(2,'0')).join('');}
  function validCode(code){return /^DS1-[a-f0-9]{64}$/.test(code);}
  function legacy(){const raw=localStorage.getItem(KEY);if(!raw)return [];const rows=JSON.parse(raw);if(!Array.isArray(rows))throw new Error('기존 데이터를 읽을 수 없습니다. 원본을 보존했습니다.');return rows;}
  function canonical(item){const {id,version,updatedAt,...data}=item;const sort=x=>Array.isArray(x)?x.map(sort):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sort(x[k])])):x;return JSON.stringify(sort(data));}
  class CloudStore {
    constructor(url,code,onMutation=()=>{}){this.url=url;this.code=code;this.mode='cloud';this.userId='personal';this.busy=false;this.onMutation=onMutation;}
    async request(action,extra={}){
      const body=JSON.stringify({action,code:this.code,...extra});
      for(let attempt=0;attempt<2;attempt++){
        const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
        try{const r=await fetch(this.url,{method:'POST',headers:{'Content-Type':'application/json'},body,signal:controller.signal,credentials:'omit',cache:'no-store',referrerPolicy:'no-referrer'});let data;try{data=await r.json();}catch{throw new Error('웹 저장 서버의 응답을 확인하지 못했습니다.');}if(r.status===409)throw new ConflictError();if(!r.ok){const e=new Error(data.error||'웹 저장에 실패했습니다.');e.server=true;throw e;}return data;}
        catch(e){if(e instanceof ConflictError||e.server||attempt===1)throw e.name==='AbortError'?new Error('응답이 늦습니다. 새로고침으로 저장 여부를 확인해 주세요.'):e;}
        finally{clearTimeout(timer);}
      }
    }
    async list(){return (await this.request('list')).items;}
    async mutate(action,extra){if(this.busy)throw new Error('앞선 저장을 처리 중입니다. 잠시 후 다시 시도해 주세요.');this.busy=true;this.onMutation();try{return await this.request(action,{...extra,operation:crypto.randomUUID()});}finally{this.busy=false;this.onMutation();}}
    async save(item){return (await this.mutate('save',{item})).item;}
    async remove(item){await this.mutate('delete',{item:{id:item.id,version:item.version}});}
    async migrate(){if(this.busy)throw new Error('저장 중입니다. 잠시 후 다시 시도해 주세요.');const original=localStorage.getItem(KEY),rows=legacy();for(const row of rows){const error=DayCore.validate(row);if(error)throw new Error('기존 항목 확인 필요: '+error);}this.busy=true;this.onMutation();try{for(let i=0;i<rows.length;i+=40)await this.request('import',{items:rows.slice(i,i+40)});const remote=await this.list();for(const row of rows){const saved=remote.find(x=>x.id===row.id);if(!saved||canonical(saved)!==canonical(row))throw new Error('서버의 같은 항목이 다르게 수정되어 있습니다. 기존 기기 데이터는 보존했습니다.');}if(localStorage.getItem(KEY)!==original)throw new Error('옮기는 동안 기존 데이터가 변경되어 원본을 보존했습니다.');localStorage.removeItem(KEY);return rows.length;}finally{this.busy=false;this.onMutation();}}
  }
  return {CloudStore,ConflictError,KEY,SESSION,newCode,validCode,legacy,canonical};
})();
if(typeof module!=='undefined')module.exports=DayStore;
