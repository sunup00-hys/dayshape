const DayStore = (() => {
  const KEY='dayshape.preview.v1';
  class ConflictError extends Error { constructor(){super('다른 화면에서 변경된 항목입니다. 새로고침 후 다시 수정해 주세요.');} }
  class LocalStore {
    constructor(){this.mode='local';this.userId='preview';}
    read(){const raw=localStorage.getItem(KEY);if(!raw)return [];const data=JSON.parse(raw);if(!Array.isArray(data))throw new Error('저장된 데이터를 읽을 수 없습니다. 기존 데이터를 보존했습니다.');return data;}
    async list(){return this.read();}
    async save(item){const all=this.read(),index=all.findIndex(x=>x.id===item.id);if(index>=0&&all[index].version!==item.version)throw new ConflictError();if(index<0&&item.version>0)throw new ConflictError();const next={...item,version:(item.version||0)+1,updatedAt:new Date().toISOString()};if(index<0)all.push(next);else all[index]=next;localStorage.setItem(KEY,JSON.stringify(all));return next;}
    async remove(item){const all=this.read(),found=all.find(x=>x.id===item.id);if(!found||found.version!==item.version)throw new ConflictError();localStorage.setItem(KEY,JSON.stringify(all.filter(x=>x.id!==item.id)));}
  }
  class CloudStore {
    constructor(client,userId){this.client=client;this.userId=userId;this.mode='cloud';}
    unpack(row){return {...row.payload,id:row.id,version:row.version,updatedAt:row.updated_at};}
    async list(){const all=[];for(let start=0;;start+=500){const {data,error}=await this.client.from('dayshape_items').select('id,payload,version,updated_at').eq('owner_id',this.userId).order('id').range(start,start+499);if(error)throw error;all.push(...data.map(r=>this.unpack(r)));if(data.length<500)break;}return all;}
    async save(item){const {version=0,id,updatedAt,...payload}=item;let query;if(version===0)query=this.client.from('dayshape_items').insert({id,owner_id:this.userId,payload,version:1});else query=this.client.from('dayshape_items').update({payload,version:version+1,updated_at:new Date().toISOString()}).eq('id',id).eq('owner_id',this.userId).eq('version',version);const {data,error}=await query.select('id,payload,version,updated_at');if(error)throw error;if(data.length!==1)throw new ConflictError();return this.unpack(data[0]);}
    async remove(item){const {data,error}=await this.client.from('dayshape_items').delete().eq('id',item.id).eq('owner_id',this.userId).eq('version',item.version).select('id');if(error)throw error;if(data.length!==1)throw new ConflictError();}
  }
  return {LocalStore,CloudStore,ConflictError,KEY};
})();
