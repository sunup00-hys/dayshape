/* Date-only calculations use UTC; displayed wall-clock time uses Asia/Seoul. */
const DayCore = (() => {
  const DAY = 86400000;
  const repeats = {none:'반복 없음', w1:'매주', w2:'격주', m1:'매월', m2:'2개월마다', m3:'3개월마다', m6:'6개월마다', m12:'매년'};
  const stages = {due:'업무 마감', proto:'1차 프로토', verify:'1차 검증', final:'최종 납기', meeting:'미팅',company:'회사 일정'};
  const priorities = {urgent:'최우선', high:'높음', normal:'보통', low:'낮음'};
  function date(s) { return new Date(s+'T00:00:00Z'); }
  function fmt(d) { return d.toISOString().slice(0,10); }
  function validDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(s||'') && !isNaN(date(s)) && fmt(date(s)) === s && s>='1900-01-01' && s<='2199-12-31'; }
  function plusDays(s,n) { return fmt(new Date(date(s).getTime()+n*DAY)); }
  function diff(a,b) { return Math.round((date(a)-date(b))/DAY); }
  function plusMonths(s,n) { const d=date(s), target=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+n,1)), end=new Date(Date.UTC(target.getUTCFullYear(),target.getUTCMonth()+1,0)).getUTCDate();target.setUTCDate(Math.min(d.getUTCDate(),end));return fmt(target); }
  function shift(s,rule,n) { if(!s)return '';if(rule==='none'||!n)return s;return rule[0]==='w'?plusDays(s,7*Number(rule.slice(1))*n):plusMonths(s,Number(rule.slice(1))*n); }
  function today(now=new Date()) { return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now); }
  function stamp(day,time='00:00') { return new Date(day+'T'+time+':00+09:00').getTime(); }
  function fields(item) { if(item.kind!=='task') return [{stage:item.kind,date:item.date}];const a=['proto','verify','final'].filter(k=>item[k]).map(k=>({stage:k,date:item[k]}));return a.length?a:[{stage:'due',date:item.date}]; }
  function anchor(item) { return item.kind!=='task'?item.date:[item.begin,...fields(item).map(x=>x.date)].filter(Boolean).sort()[0]; }
  function validate(item) {
    if(!item||!['task','meeting','company'].includes(item.kind))return '구분을 선택해 주세요.';
    if(typeof item.title!=='string'||!item.title.trim()||item.title.length>120)return '제목은 1~120자로 입력해 주세요.';
    if(!(item.priority in priorities)||!(item.repeat in repeats))return '중요도와 반복 주기를 확인해 주세요.';
    if(!validDate(item.date))return '기준일을 확인해 주세요.';
    for(const k of ['begin','proto','verify','final','endDate','until'])if(item[k]&&!validDate(item[k]))return '날짜를 확인해 주세요. (1900~2199년)';
    if(item.kind==='meeting') {
      if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(item.start||'')||!/^([01]\d|2[0-3]):[0-5]\d$/.test(item.end||''))return '미팅 시작·종료 시간을 입력해 주세요.';
      if(stamp(item.endDate||item.date,item.end)<=stamp(item.date,item.start))return '종료 일시는 시작 일시 이후여야 합니다.';
      if(diff(item.endDate||item.date,item.date)>7)return '한 미팅은 7일 이내로 등록해 주세요.';
    } else if(item.kind==='company') {
      if(!['해프','공동연차','전체 일정','추가 휴일'].includes(item.category))return '회사 일정 종류를 선택해 주세요.';
      if(!['full','am','pm'].includes(item.portion))return '종일 또는 오전·오후를 선택해 주세요.';
      if(!validDate(item.endDate)||item.endDate<item.date||diff(item.endDate,item.date)>366)return '종료일은 시작일 이후, 366일 이내로 입력해 주세요.';
    } else {
      const sequence=[item.begin,item.proto,item.verify,item.final].filter(Boolean);
      if(sequence.some((x,i)=>i>0&&x<sequence[i-1]))return '시작 → 프로토 → 검증 → 최종 납기 순서로 날짜를 입력해 주세요.';
      if(item.begin&&!fields(item).some(x=>x.date>=item.begin))return '마감일은 시작일 이후여야 합니다.';
    }
    if(item.repeat!=='none'&&item.until&&item.until<anchor(item))return '반복 종료일은 첫 회차 시작일 이후여야 합니다.';
    if((item.remark||'').length>10000)return '리마크는 10,000자 이내로 입력해 주세요.';
    return '';
  }
  function occurrences(items,from,to) {
    const out=[];
    for(const item of items) {
      if(validate(item))continue;
      const base=anchor(item), lastField=[...fields(item).map(x=>x.date),item.kind!=='task'?(item.endDate||item.date):item.date].sort().at(-1);
      let startN=0;
      if(item.repeat[0]==='w')startN=Math.max(0,Math.floor(diff(from,lastField)/(7*Number(item.repeat.slice(1))))-1);
      if(item.repeat[0]==='m'){const a=date(from),b=date(lastField);startN=Math.max(0,Math.floor(((a.getUTCFullYear()-b.getUTCFullYear())*12+a.getUTCMonth()-b.getUTCMonth())/Number(item.repeat.slice(1)))-1);}
      const limit=item.repeat==='none'?1:16000;
      for(let n=startN;n<limit;n++) {
        const cycle=shift(base,item.repeat,n);
        if(cycle>to||(item.repeat!=='none'&&item.until&&cycle>item.until))break;
        for(const f of fields(item)) {
          const day=shift(f.date,item.repeat,n),endDay=item.kind!=='task'?shift(item.endDate||item.date,item.repeat,n):day;
          if(day>to||endDay<from)continue;
          const completionKey=n+':'+f.stage;
          out.push({id:item.id+'|'+completionKey,itemId:item.id,item,n,stage:f.stage,date:day,endDate:endDay,done:!!item.completed?.[completionKey],completionKey});
        }
        if(item.repeat==='none')break;
      }
    }
    const ranks={urgent:0,high:1,normal:2,low:3};
    return out.sort((a,b)=>a.date.localeCompare(b.date)||(a.item.start||'99').localeCompare(b.item.start||'99')||ranks[a.item.priority]-ranks[b.item.priority]||a.item.title.localeCompare(b.item.title));
  }
  function bounds(selected,view) {if(view==='day')return [selected,selected];if(view==='week'){const start=plusDays(selected,-date(selected).getUTCDay());return[start,plusDays(start,6)];}const d=date(selected),first=fmt(new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),1))),last=fmt(new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)));return[plusDays(first,-date(first).getUTCDay()),plusDays(last,6-date(last).getUTCDay())];}
  function shouldAlert(e,now=Date.now()) { return e.item.kind==='meeting'&&stamp(e.date,e.item.start)<=now&&stamp(e.endDate,e.item.end)>now; }
  function deadline(day,done=false,reference=today()) {
    if(done)return {label:'완료',state:'done',urgent:false};
    const remaining=diff(day,reference);
    if(remaining<0)return {label:'D+'+Math.abs(remaining),state:'overdue',urgent:true,description:Math.abs(remaining)+'일 기한 초과'};
    if(remaining===0)return {label:'D-DAY',state:'today',urgent:true,description:'오늘 마감'};
    return {label:'D-'+remaining,state:remaining<=3?'soon':'normal',urgent:remaining<=3,description:remaining+'일 후 마감'};
  }
  function visibleDays(from,to,hideWeekends=false) {return Array.from({length:diff(to,from)+1},(_,n)=>plusDays(from,n)).filter(day=>!hideWeekends||![0,6].includes(date(day).getUTCDay()));}
  return {DAY,repeats,stages,priorities,date,fmt,validDate,plusDays,plusMonths,diff,shift,today,stamp,fields,anchor,validate,occurrences,bounds,shouldAlert,deadline,visibleDays};
})();
if(typeof module!=='undefined')module.exports=DayCore;
