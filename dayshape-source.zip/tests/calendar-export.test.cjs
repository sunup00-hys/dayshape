const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const C=require('../src/core.js'),H=require('../src/holidays.js'),E=require('../src/export.js'),X=require('../src/xlsx.js');
const base={id:'demo',title:'테스트',date:'2026-10-30',priority:'normal',repeat:'none',completed:{}};
test('2026 official calendar includes lunar holidays, substitutes, election and revised holidays',()=>{
 const expected=['01-01','02-16','02-17','02-18','03-01','03-02','05-01','05-05','05-24','05-25','06-03','06-06','07-17','08-15','08-17','09-24','09-25','09-26','10-03','10-05','10-09','12-25'];
 assert.deepEqual(H.year(2026).map(e=>e.date.slice(5)),expected);
 assert.equal(H.on('2026-09-28').length,0,'Saturday in Chuseok alone must not create a substitute');
 assert.equal(H.on('2026-06-08').length,0,'Memorial Day has no substitute');
});
test('2027 official calendar and 2028-50 forecasts are distinct, unsupported years are explicit',()=>{
 const expected=['01-01','02-06','02-07','02-08','02-09','03-01','05-01','05-03','05-05','05-13','06-06','07-17','07-19','08-15','08-16','09-14','09-15','09-16','10-03','10-04','10-09','10-11','12-25','12-27'];
 assert.deepEqual(H.year(2027).map(e=>e.date.slice(5)),expected);assert.ok(H.year(2027).every(e=>!e.projected));assert.ok(H.year(2028).every(e=>e.projected));assert.equal(H.year(2051).length,0);assert.match(H.note(2051),/지원하지/);
 for(let y=2026;y<=2050;y++){const days=H.year(y);assert.ok(days.every(e=>C.validDate(e.date)));assert.ok(days.filter(e=>e.title.startsWith('대체')).every(e=>![0,6].includes(C.date(e.date).getUTCDay())));}
});
test('company ranges recur and stay visible on days after their start',()=>{
 const i={...base,kind:'company',category:'공동연차',portion:'full',date:'2026-10-30',endDate:'2026-11-02',repeat:'m12',until:'2027-10-30'};
 assert.equal(C.validate(i),'');const out=C.occurrences([i],'2027-11-01','2027-11-01');assert.equal(out.length,1);assert.equal(out[0].date,'2027-10-30');assert.equal(out[0].endDate,'2027-11-02');assert.equal(out[0].stage,'company');assert.equal(C.shouldAlert(out[0]),false);
 assert.ok(C.validate({...i,endDate:'2026-10-01'}));assert.ok(C.validate({...i,portion:'bad'}));
});
test('Excel rows retain all records, task details, recurrence and plain text',()=>{
 const items=[{...base,id:'meet',kind:'meeting',start:'09:00',end:'10:00',endDate:base.date,title:'=1+1'},{...base,id:'company',kind:'company',category:'해프',portion:'pm',endDate:base.date,repeat:'w2',remark:'한글 & <태그>\n두 번째 줄'},{...base,id:'work',kind:'task',begin:'2026-10-01',proto:'2026-10-10',verify:'2026-10-20',final:'2026-10-30',owner:'담당자',team:'팀',difficulty:'high',utility:'normal',completed:{'0:proto':true}}];
 const sheets=E.sheets(items);assert.equal(sheets.length,2);assert.equal(sheets[0].rows.length,2);assert.equal(sheets[1].rows.length,1);assert.equal(sheets[0].rows[0][1],'=1+1');assert.equal(sheets[1].rows[0][5],'높음');assert.equal(sheets[1].rows[0][16],'1회차 1차 프로토');assert.equal(sheets[1].rows[0][4].date,'2026-10-20');
 const bytes=X.build(sheets);assert.equal(bytes[0],0x50);assert.equal(bytes[1],0x4b);fs.writeFileSync('/tmp/dayshape-export-test.xlsx',bytes);assert.ok(new TextDecoder().decode(bytes).includes('t="inlineStr"'));
 const empty=X.build(E.sheets([]));fs.writeFileSync('/tmp/dayshape-empty-test.xlsx',empty);
});
