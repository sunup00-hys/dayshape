// Add only a Supabase project URL and publishable key at deployment time.
// Never put a service_role key or database password here.
window.DAYSHAPE_CONFIG = {supabaseUrl:'',publishableKey:''};
