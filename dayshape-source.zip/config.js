window.DAYSHAPE_CONFIG={apiUrl:'https://dayshape-cloud.sunup00.chatgpt.site/api/sync'};
